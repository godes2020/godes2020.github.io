# Инструкция по обновлению игры Void Clicker

## Что было создано
- **game-script-new.js** - новая версия всего JavaScript кода игры
- Полностью переписана логика энергии, баланса, достижений и крафта

## Как установить

### Шаг 1: Замена скрипта в HTML

В файле `public/index.html` найди блок `<script>` в конце файла (перед `</body>`).

Вместо всего старого скрипта вставь:
```html
<script src="game-script-new.js"></script>
<script>
    // Инициализация при загрузке страницы
    document.addEventListener('DOMContentLoaded', () => {
        initGame();
    });
</script>
```

### Шаг 2: Обновить HTML для лидерборда (4 вкладки вместо 6)

Найди в HTML блок:
```html
<div class="leaderboard-tabs">
    <button class="leaderboard-tab active" onclick="switchLeaderboard('rebirths')">...</button>
    ...
</div>
```

Замени на:
```html
<div class="leaderboard-tabs">
    <button class="leaderboard-tab active" onclick="switchLeaderboard('rebirths')">Перерождения</button>
    <button class="leaderboard-tab" onclick="switchLeaderboard('gold')">Всего Эссенций</button>
    <button class="leaderboard-tab" onclick="switchLeaderboard('clickDamage')">Урон за Клик</button>
    <button class="leaderboard-tab" onclick="switchLeaderboard('autoDamage')">Пассивный Урон</button>
</div>
```

### Шаг 3: Убедись, что есть необходимые элементы в HTML

Проверь наличие этих элементов (должны быть где-то в теле):

```html
<!-- В шапке статистики -->
<div id="gold-display">0</div>
<div id="energy-display">20/20</div>
<div id="dpc-display">1</div>
<div id="dps-display">0</div>
<div id="rebirth-points">0</div>

<!-- В сайдбаре -->
<div id="sidebar-gold">0</div>
<div id="sidebar-dpc">1</div>
<div id="sidebar-dps">0</div>

<!-- Для лидерборда -->
<div id="leaderboard-list"></div>

<!-- Для достижений -->
<div id="achievements-list"></div>

<!-- Для апгрейдов -->
<div id="click-upgrades"></div>
<div id="passive-upgrades"></div>

<!-- Для крафта -->
<div id="craft-grid"></div>

<!-- Основной экран игры -->
<div id="game-screen" style="display: none;"></div>
```

### Шаг 4: Кнопка врага

Убедись, что у кнопки врага есть обработчик клика:
```html
<button id="enemy-btn" onclick="playerClick(event)" class="enemy-button">
    Враг
</button>
```

## Что изменилось

### Энергия ✨
- **Восстановление**: 1 энергия каждые 0.5 секунды (500ms)
- **Сохранение**: энергия сохраняется в localStorage, не теряется при обновлении страницы
- **Использование**: 1 энергия на клик

### Лидерборд 🏅
- Вместо 6 вкладок → только 4:
  - Перерождения
  - Всего Эссенций
  - Урон за Клик
  - Пассивный Урон
- Удалены: "Всего RP" и "Пассивных RP"

### Достижения 🏆
- Максимум **3 очка за достижение** (было до 5+)
- **Без всплывающих уведомлений** (alert)
- 12 достижений в игре

### Баланс 💰
- **Пассивные дешевле на 20%**: 
  - Клик: 50, 150, 400, 1500, 7500
  - Пассив: 40, 130, 350, 1300, 6500
- Примерно одинаковый прирост урона

### Крафт 🔧
- 11 рецептов вместо 8
- Новые ресурсы: core, star_shard
- Баланс по энергии скорректирован

### Сохранение 💾
- **Автосохранение каждые 5 секунд** в localStorage
- При закрытии страницы - сохранение
- При клике - немедленное сохранение энергии

## Возможные проблемы

### "Энергия не восстанавливается"
1. Открой DevTools (F12)
2. Посмотри Console
3. Должно быть сообщение: "⚡ Energy regen started"
4. Если нет - проверь, что `initGame()` вызывается при загрузке

### "Лидерборд не загружается"
1. Убедись, что на сервере (server.js) эндпоинт `/api/leaderboard` работает
2. Должны обрабатываться только 4 типа: rebirths, gold, clickDamage, autoDamage
3. Проверь Network tab в DevTools

### "Достижения не даются"
1. Проверь Console в DevTools
2. Должны быть логи вроде: "🏆 Achievement unlocked: Первый шаг"
3. Убедись, что прогресс достаточен (например, для "gold_1k" нужно 1000 эссенций)

## Команды для консоли (DevTools, F12)

```javascript
// Посмотреть текущее состояние
console.log({gold, dpc, dps, energy, maxEnergy, rebirthLevel});

// Дать себе денег для тестирования
gold = 100000; updateUI(); saveGame();

// Дать энергии
energy = maxEnergy; updateEnergyUI();

// Запустить достижение вручную
checkAchievements();

// Очистить сохранение (новая игра)
localStorage.removeItem("void_clicker_save");
location.reload();
```

## Если что-то сломалось

1. Откройте DevTools (F12 → Console)
2. Посмотрите на ошибки (красные строки)
3. Скиньте сюда скриншот ошибки или сам текст ошибки
4. Я помогу переделать нужный блок

## Готово!

После этих шагов игра должна работать полностью:
- ✅ Энергия восстанавливается и сохраняется
- ✅ Лидерборд только с 4 вкладками
- ✅ Достижения без уведомлений, макс 3 очка
- ✅ Баланс пассивных лучше
- ✅ Больше рецептов крафта
- ✅ Сохранение работает надежно
